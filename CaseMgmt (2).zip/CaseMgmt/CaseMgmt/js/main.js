
'use strict'

/**
 * Main AngularJS Web Application
 */
 
var baskets = [];
var cases= [];
var searchdetails = [];
 
var caseMgmtApp = angular.module('caseMgmtApp', ['ngRoute','angularUtils.directives.dirPagination','angularjs-datetime-picker']);


/**
 * Configure the Routes
 */
caseMgmtApp.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html"})
    // Pages
	.when("/inbasket", {templateUrl: "partials/inbasket.html"})
    .when("/caseview", {templateUrl: "partials/caseView.html"})
	.when("/createcase", {templateUrl: "partials/createcase.html"})
	.when("/case", {templateUrl: "partials/cases.html"})
	.when("/search", {templateUrl: "partials/search.html"})
	.when("/searchView", {templateUrl: "partials/searchView.html"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);




