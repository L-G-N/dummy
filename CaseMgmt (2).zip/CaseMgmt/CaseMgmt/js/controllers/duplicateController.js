
'use strict'

caseMgmtApp.controller('duplicateController', function ($scope, $location, $http) {
	console.log("duplicateController Controller reporting ");
	
	
	
$scope.createCase = window.variable;


});