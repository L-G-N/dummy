'use strict'

caseMgmtApp.controller('inBasketController', function ($scope, $location, BasketService) {
		console.log("inBasketController Controller reporting for duty."+baskets.length);
		
		$scope.baskets = baskets;	
		
		console.log("$scope.baskets-->"+baskets[0].name);
		
		$scope.sort = function(keyname){
			$scope.sortKey = keyname;   //set the sortKey to the param passed
			$scope.reverse = !$scope.reverse; //if true make it false and vice versa
		}
		
		$scope.viewCaseDetailst = function(basketid) {
		alert("View Case"+ basketid);
		 BasketService.fetchAllCases().then(
				   function(resp) {
						cases = resp;
						console.log("Cases"+cases);
						console.log("$scope.cases-->"+cases[0].caseId);
						$location.path("/case");
						
	
				   },
					function(errResponse){
						console.error('Error while fetching Currencies');
					}
			   );
					
		}; 
		$scope.casedetails = cases;
		
   
});



