'use strict'

caseMgmtApp.controller('searchViewController', function ($scope, $location, BasketService) {
		console.log("searchViewController Controller reporting for duty.");
		
	$scope.showDetails = false;
	var validForm = false;
	var srchCase = new Object();
	$scope.submitSearchCaseForm = function (){
		
		srchCase = $scope.searchCase;
		console.log("srchCase-->"+srchCase);
		
		if( (!angular.isUndefined(srchCase.businessName) && srchCase.businessName.length > 0) || 
			(!angular.isUndefined(srchCase.custNumber) && srchCase.custNumber.length > 0) || 
			(!angular.isUndefined(srchCase.acctNumber) && srchCase.acctNumber.length > 0)){
			
			
			console.log("first case-->"+srchCase);
			validForm = true;
			
		}else{
			if(angular.isUndefined(srchCase.surname)){
				if(angular.isUndefined(srchCase.firstName)){
					validForm = true;
				}else if(srchCase.firstName.length >= 0){
					$("#errMsg").removeClass("ng-hide");
					console.log("Surname undefined - firstName length 0");
					$scope.error='Surname and First Name is Mandatory';
				}		
			}else if(srchCase.surname.length > 0){
				if(angular.isUndefined(srchCase.firstName) || srchCase.firstName.length == 0){
					$("#errMsg").removeClass("ng-hide");
					console.log("Surname >0 - firstName length undefined");
					$scope.error='Surname and First Name is Mandatory';				
				}else if(srchCase.firstName.length > 0){
					validForm = true;
				}		
			}else if (srchCase.surname.length ==0 && srchCase.firstName.length==0){
				validForm = true;
			}else if (srchCase.surname.length ==0 && srchCase.firstName.length>0){
				$("#errMsg").removeClass("ng-hide");
				console.log("Surname 0 - firstName > 0");
					$scope.error='Surname and First Name is Mandatory';
			}
		}
		
		
		
		
		if(validForm){
			validForm = false;
			$("#errMsg").addClass("ng-hide");
			BasketService.getCaseDetails(srchCase).then(
			   function(resp) {
					$scope.showDetails = true;
					searchdetails = resp;
					console.log("Cases Details"+searchdetails);
					console.log("$scope.cases-->"+searchdetails[0].caseId);
					$scope.details = searchdetails;
					console.log("$scope-->"+searchdetails);
					
			   },
				function(errResponse){
					console.error('Error while fetching Currencies');
				}
			);			
		}	
	}
			
	$scope.searchViewCase = function(){
		$location.path("/searchView");
	}
   
});

caseMgmtApp.directive('allowPattern', [allowPatternDirective]);
                                   
function allowPatternDirective() {
    return {
        restrict: "A",
        compile: function(tElement, tAttrs) {
            return function(scope, element, attrs) {
        // I handle key events
                element.bind("keypress", function(event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.
          
          // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                    if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
            event.preventDefault();
                        return false;
                    }
          
                });
            };
        }
    };
}