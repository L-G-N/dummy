
'use strict'

caseMgmtApp.controller('homeController', function ($scope, $location, BasketService) {
	console.log("homeCtrl Controller reporting for duty.");
		
	$scope.inBasketButton = function (){
		
		 BasketService.fetchAllBaskets().then(
				   function(resp) {
						baskets = resp;
						console.log(baskets);
						$location.path("/inbasket");
				   },
					function(errResponse){
						console.error('Error while fetching Currencies');
					}
			   );
					   
				
		
	};
	
	$scope.caseViewButton = function (){
		//alert("case basket");
		$location.path("/caseview");
	};
	
	$scope.searchViewButton = function (){
		//alert("search case");
		$location.path("/search");
	};
	
    $scope.isActive = function(viewLocation) {
		return viewLocation === $location.path();
	};
});



