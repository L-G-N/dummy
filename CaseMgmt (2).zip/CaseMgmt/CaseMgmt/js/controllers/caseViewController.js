
'use strict'

caseMgmtApp.controller('caseViewController', function ($scope, $location, $http, $window) {
	console.log("CaseView Controller reporting ");
	$scope.test = false;
	//var createCases = [];
	$scope.customerView = {};
	$scope.accountView = {};
	$scope.mmpAccountView = {};
	$scope.assistanceView = {};
	//$scope.eventView = {};	
	
	$scope.createCase = {};
	
	
	$scope.createCaseForm = function (){
		
		alert("clicked create button");
	}
	
		$scope.duplicate = function(createCase){
			$scope.test = true;
		alert("Inside Duplicate");
		// angular.copy(createCase, $scope.createCase);
		
		 $window.open("file:///E:/Rupa/CaseMgmt/CaseMgmt/index.html#/createcase").variable = createCase;
			//$scope.createCase = createCases;
		
	};


});