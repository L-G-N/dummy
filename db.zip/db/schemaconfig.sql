-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.14-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for los
CREATE DATABASE IF NOT EXISTS `los` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `los`;


-- Dumping structure for table los.binmapref
CREATE TABLE IF NOT EXISTS `binmapref` (
  `BINNUMBER` decimal(6,0) NOT NULL,
  `SCHEME` varchar(20) DEFAULT NULL,
  `BANK` varchar(10) DEFAULT NULL,
  `CARDTYPE` varchar(20) DEFAULT NULL,
  `ORG` char(3) DEFAULT NULL,
  PRIMARY KEY (`BINNUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.binmapref: ~0 rows (approximately)
/*!40000 ALTER TABLE `binmapref` DISABLE KEYS */;
/*!40000 ALTER TABLE `binmapref` ENABLE KEYS */;


-- Dumping structure for table los.cardstatus
CREATE TABLE IF NOT EXISTS `cardstatus` (
  `PAN` varchar(19) NOT NULL,
  `INVALIDCVVCOUNT` decimal(2,0) DEFAULT NULL,
  PRIMARY KEY (`PAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.cardstatus: ~1 rows (approximately)
/*!40000 ALTER TABLE `cardstatus` DISABLE KEYS */;
INSERT INTO `cardstatus` (`PAN`, `INVALIDCVVCOUNT`) VALUES
	('6969876', 0);
/*!40000 ALTER TABLE `cardstatus` ENABLE KEYS */;


-- Dumping structure for table los.custmobile
CREATE TABLE IF NOT EXISTS `custmobile` (
  `CUSTMOBILEID` decimal(15,0) NOT NULL,
  `CUSTOMERID` decimal(15,0) NOT NULL,
  `CPLC` varchar(84) NOT NULL,
  `MOBILENAME` varchar(20) DEFAULT NULL,
  `STATUS` char(1) NOT NULL,
  `CREATIONDT` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UPDATIONDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `LASTCARDRMVDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `MEMOTEXT` varchar(180) DEFAULT NULL,
  `FCTRESETRSN` char(1) DEFAULT NULL,
  `FRCASEOPENDT` timestamp NULL DEFAULT NULL,
  `FRCASECLOSEDT` timestamp NULL DEFAULT NULL,
  `APPBRAND` char(4) DEFAULT NULL,
  `SERVICETYPE` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CUSTMOBILEID`),
  KEY `FK_custmobile_customer` (`CUSTOMERID`),
  CONSTRAINT `FK_custmobile_customer` FOREIGN KEY (`CUSTOMERID`) REFERENCES `customer` (`CUSTOMERID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.custmobile: ~0 rows (approximately)
/*!40000 ALTER TABLE `custmobile` DISABLE KEYS */;
/*!40000 ALTER TABLE `custmobile` ENABLE KEYS */;


-- Dumping structure for table los.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `CUSTOMERID` decimal(15,0) NOT NULL,
  `FIRSTNM` varchar(45) DEFAULT NULL,
  `MIDDLENM` varchar(45) DEFAULT NULL,
  `LASTNM` varchar(45) DEFAULT NULL,
  `BIRTHDT` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`CUSTOMERID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


-- Dumping structure for table los.domaincustomer
CREATE TABLE IF NOT EXISTS `domaincustomer` (
  `CUSTOMERID` decimal(15,0) DEFAULT NULL,
  `CUSTOMERNUM` varchar(8) NOT NULL,
  `DOMAIN` varchar(4) DEFAULT NULL,
  `CISKEY` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`CUSTOMERNUM`),
  KEY `FK_domaincustomer_customer` (`CUSTOMERID`),
  CONSTRAINT `FK_domaincustomer_customer` FOREIGN KEY (`CUSTOMERID`) REFERENCES `customer` (`CUSTOMERID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.domaincustomer: ~0 rows (approximately)
/*!40000 ALTER TABLE `domaincustomer` DISABLE KEYS */;
/*!40000 ALTER TABLE `domaincustomer` ENABLE KEYS */;


-- Dumping structure for table los.enrollmentdetails
CREATE TABLE IF NOT EXISTS `enrollmentdetails` (
  `REQUESTID` decimal(30,0) NOT NULL,
  `TOKENREFID` varchar(14) DEFAULT NULL,
  `SCHEMETYPE` varchar(20) DEFAULT NULL,
  `Column 4` varchar(20) DEFAULT NULL,
  `EMBOSSEDNAME` varchar(48) DEFAULT NULL,
  `DEVICEID` varchar(64) DEFAULT NULL,
  `FPAN` varchar(19) DEFAULT NULL,
  `DPAN` varchar(19) DEFAULT NULL,
  `REASONCODE` varchar(5) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `SERVICETYPE` varchar(50) DEFAULT NULL,
  `CARDEXPIRY` varchar(4) DEFAULT NULL,
  `CREATEDDT` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UPDATEDDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `WALLETID` varchar(3) DEFAULT NULL,
  `DEVICENAME` varchar(64) DEFAULT NULL,
  `ISODEVICETYPE` varchar(2) DEFAULT NULL,
  `STOCKID` varchar(8) DEFAULT NULL,
  `SUFFIX` varchar(3) DEFAULT NULL,
  `SOURCEIP` varchar(64) DEFAULT NULL,
  `DEVICELOCATION` varchar(64) DEFAULT NULL,
  `DEVICESCORE` varchar(64) DEFAULT NULL,
  `TOKENREQUESTORID` varchar(11) DEFAULT NULL,
  `RECOMMENDEDDECISION` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`REQUESTID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.enrollmentdetails: ~0 rows (approximately)
/*!40000 ALTER TABLE `enrollmentdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollmentdetails` ENABLE KEYS */;


-- Dumping structure for table los.mobilecard
CREATE TABLE IF NOT EXISTS `mobilecard` (
  `MOBILECARDID` decimal(15,0) NOT NULL,
  `CUSTMOBILEID` decimal(15,0) DEFAULT NULL,
  `LARN` char(9) DEFAULT NULL,
  `CARDNUM` char(16) DEFAULT NULL,
  `SUFFIX` char(3) DEFAULT NULL,
  `BASECARDSUFFIX` char(3) DEFAULT NULL,
  `CARDSTATUS` char(1) DEFAULT NULL,
  `LOGO` char(3) DEFAULT NULL,
  `CARDTYPE` char(1) DEFAULT NULL,
  `ACCOUNTNAME` varchar(50) DEFAULT NULL,
  `ACCOUNTNUM` char(19) DEFAULT NULL,
  `MAID` varchar(40) DEFAULT NULL,
  `SEQUENCENUM` smallint(6) DEFAULT NULL,
  `CREATIONDT` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UPDATIONDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `CARDSCRIPTAVLDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `BASEPLSTCSTCKID` varchar(8) DEFAULT NULL,
  `MOBRETRYIND` char(2) DEFAULT NULL,
  `EMBSRRCDCRTD` char(1) DEFAULT NULL,
  `EMBSRRCDCRTDDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `EMBPERSDTRECVD` char(1) DEFAULT NULL,
  `EMBPERSDTRECVDDT` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `EMBSRECDDELTD` char(1) DEFAULT NULL,
  `EMBSRECDDELTDDT` timestamp NULL DEFAULT NULL,
  `MOBILEAPPVERSION` varchar(50) DEFAULT NULL,
  `SEELIGIBLEIND` char(1) DEFAULT NULL,
  `CARDELIGIBLEIND` char(1) DEFAULT NULL,
  `CASENUMBER` char(2) DEFAULT NULL,
  `PUSHNOTFREQDDT` timestamp NULL DEFAULT NULL,
  `PUSHNOTFSENTFLAG` char(3) DEFAULT NULL,
  `PUSHNOTFREMDRSENTDT` timestamp NULL DEFAULT NULL,
  `PUSHNOTFREMDRCNT` decimal(2,0) DEFAULT NULL,
  `CARDEXPIRY` varchar(4) DEFAULT NULL,
  `DPAN` varchar(19) DEFAULT NULL,
  `TOKENREFID` varchar(14) DEFAULT NULL,
  `2FAMOBILENUMBER` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`MOBILECARDID`),
  KEY `FK_mobilecard_custmobile` (`CUSTMOBILEID`),
  CONSTRAINT `FK_mobilecard_custmobile` FOREIGN KEY (`CUSTMOBILEID`) REFERENCES `custmobile` (`CUSTMOBILEID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.mobilecard: ~0 rows (approximately)
/*!40000 ALTER TABLE `mobilecard` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobilecard` ENABLE KEYS */;


-- Dumping structure for table los.schemeconfig
CREATE TABLE IF NOT EXISTS `schemeconfig` (
  `CONFIGPARAM` varchar(20) NOT NULL,
  `CONFIGVALUE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CONFIGPARAM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.schemeconfig: ~0 rows (approximately)
/*!40000 ALTER TABLE `schemeconfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `schemeconfig` ENABLE KEYS */;


-- Dumping structure for table los.smsdetails
CREATE TABLE IF NOT EXISTS `smsdetails` (
  `SMSID` decimal(15,0) DEFAULT NULL,
  `MOBILECARDID` decimal(15,0) DEFAULT NULL,
  `MOBILENUMBER` varchar(15) DEFAULT NULL,
  `CREATEDDT` timestamp NULL DEFAULT NULL,
  `UPDATEDT` timestamp NULL DEFAULT NULL,
  KEY `FK_smsdetails_mobilecard` (`MOBILECARDID`),
  CONSTRAINT `FK_smsdetails_mobilecard` FOREIGN KEY (`MOBILECARDID`) REFERENCES `mobilecard` (`MOBILECARDID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table los.smsdetails: ~0 rows (approximately)
/*!40000 ALTER TABLE `smsdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsdetails` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
