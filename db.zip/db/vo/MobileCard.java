package au.com.westpac.ulo.db.vo;
import java.sql.Timestamp;

public class MobileCard {

	private double mobileCardId;
	private double custMobileId;
	private char larn;
	private char CardNum;
	private char suffix;
	private char baseCardSuffix;
	private char cardStatus;
	private char logo;
	private char cardType;
	private String accountName;
	private char accountNum;
	private String maid;
	private int sequenceNum;
	private Timestamp creationDt;
	private Timestamp updationDt;
	private Timestamp cardScriptAvlDt;
	private String basePlstCstCkid;
	private char mobRetryInd;
	private char embsrrcdcrtd;
	private Timestamp embsrrcdcrtddt;
	private char embpersdtrecvd;
	private Timestamp embpersdtrecvddt;
	private char embsrecddeltd;
	private Timestamp embsrecddeltddt;
	private String mobileAppVersion;
	private char seEligibleInd;
	private char cardEligibleInd;
	private char caseNumber;
	private Timestamp pushNotFreqDdt;
	private char pushNotFsentFlag;
	private Timestamp pushNotFremdrSentDt;
	private double pushNotFremdrCnt;
	private Timestamp expiryDate;
	private String status;
	private String dPan;
	private CustMobile custMobile;
	public CustMobile getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(CustMobile custMobile) {
		this.custMobile = custMobile;
	}
	public double getMobileCardId() {
		return mobileCardId;
	}
	public void setMobileCardId(double mobileCardId) {
		this.mobileCardId = mobileCardId;
	}
	public double getCustMobileId() {
		return custMobileId;
	}
	public void setCustMobileId(double custMobileId) {
		this.custMobileId = custMobileId;
	}
	public char getCardNum() {
		return CardNum;
	}
	public char getLarn() {
		return larn;
	}
	public void setLarn(char larn) {
		this.larn = larn;
	}
	public void setCardNum(char cardNum) {
		CardNum = cardNum;
	}
	public char getSuffix() {
		return suffix;
	}
	public void setSuffix(char suffix) {
		this.suffix = suffix;
	}
	public char getBaseCardSuffix() {
		return baseCardSuffix;
	}
	public void setBaseCardSuffix(char baseCardSuffix) {
		this.baseCardSuffix = baseCardSuffix;
	}
	public char getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(char cardStatus) {
		this.cardStatus = cardStatus;
	}
	public char getLogo() {
		return logo;
	}
	public void setLogo(char logo) {
		this.logo = logo;
	}
	public char getCardType() {
		return cardType;
	}
	public void setCardType(char cardType) {
		this.cardType = cardType;
	}

	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public char getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(char accountNum) {
		this.accountNum = accountNum;
	}
	public String getMaid() {
		return maid;
	}
	public void setMaid(String maid) {
		this.maid = maid;
	}
	public int getSequenceNum() {
		return sequenceNum;
	}
	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}
	public Timestamp getCreationDt() {
		return creationDt;
	}
	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}
	public Timestamp getUpdationDt() {
		return updationDt;
	}
	public void setUpdationDt(Timestamp updationDt) {
		this.updationDt = updationDt;
	}
	public Timestamp getCardScriptAvlDt() {
		return cardScriptAvlDt;
	}
	public void setCardScriptAvlDt(Timestamp cardScriptAvlDt) {
		this.cardScriptAvlDt = cardScriptAvlDt;
	}
	public String getBasePlstCstCkid() {
		return basePlstCstCkid;
	}
	public void setBasePlstCstCkid(String basePlstCstCkid) {
		this.basePlstCstCkid = basePlstCstCkid;
	}
	public char getMobRetryInd() {
		return mobRetryInd;
	}
	public void setMobRetryInd(char mobRetryInd) {
		this.mobRetryInd = mobRetryInd;
	}
	public char getEmbsrrcdcrtd() {
		return embsrrcdcrtd;
	}
	public void setEmbsrrcdcrtd(char embsrrcdcrtd) {
		this.embsrrcdcrtd = embsrrcdcrtd;
	}
	public Timestamp getEmbsrrcdcrtddt() {
		return embsrrcdcrtddt;
	}
	public void setEmbsrrcdcrtddt(Timestamp embsrrcdcrtddt) {
		this.embsrrcdcrtddt = embsrrcdcrtddt;
	}
	public char getEmbpersdtrecvd() {
		return embpersdtrecvd;
	}
	public void setEmbpersdtrecvd(char embpersdtrecvd) {
		this.embpersdtrecvd = embpersdtrecvd;
	}
	public Timestamp getEmbpersdtrecvddt() {
		return embpersdtrecvddt;
	}
	public void setEmbpersdtrecvddt(Timestamp embpersdtrecvddt) {
		this.embpersdtrecvddt = embpersdtrecvddt;
	}
	public char getEmbsrecddeltd() {
		return embsrecddeltd;
	}
	public void setEmbsrecddeltd(char embsrecddeltd) {
		this.embsrecddeltd = embsrecddeltd;
	}
	public Timestamp getEmbsrecddeltddt() {
		return embsrecddeltddt;
	}
	public void setEmbsrecddeltddt(Timestamp embsrecddeltddt) {
		this.embsrecddeltddt = embsrecddeltddt;
	}
	public String getMobileAppVersion() {
		return mobileAppVersion;
	}
	public void setMobileAppVersion(String mobileAppVersion) {
		this.mobileAppVersion = mobileAppVersion;
	}
	public char getSeEligibleInd() {
		return seEligibleInd;
	}
	public void setSeEligibleInd(char seEligibleInd) {
		this.seEligibleInd = seEligibleInd;
	}
	public char getCardEligibleInd() {
		return cardEligibleInd;
	}
	public void setCardEligibleInd(char cardEligibleInd) {
		this.cardEligibleInd = cardEligibleInd;
	}
	public char getCaseNumber() {
		return caseNumber;
	}
	public void setCaseNumber(char caseNumber) {
		this.caseNumber = caseNumber;
	}
	public Timestamp getPushNotFreqDdt() {
		return pushNotFreqDdt;
	}
	public void setPushNotFreqDdt(Timestamp pushNotFreqDdt) {
		this.pushNotFreqDdt = pushNotFreqDdt;
	}
	public char getPushNotFsentFlag() {
		return pushNotFsentFlag;
	}
	public void setPushNotFsentFlag(char pushNotFsentFlag) {
		this.pushNotFsentFlag = pushNotFsentFlag;
	}
	public Timestamp getPushNotFremdrSentDt() {
		return pushNotFremdrSentDt;
	}
	public void setPushNotFremdrSentDt(Timestamp pushNotFremdrSentDt) {
		this.pushNotFremdrSentDt = pushNotFremdrSentDt;
	}
	public double getPushNotFremdrCnt() {
		return pushNotFremdrCnt;
	}
	public void setPushNotFremdrCnt(double pushNotFremdrCnt) {
		this.pushNotFremdrCnt = pushNotFremdrCnt;
	}
	public Timestamp getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getdPan() {
		return dPan;
	}
	public void setdPan(String dPan) {
		this.dPan = dPan;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
