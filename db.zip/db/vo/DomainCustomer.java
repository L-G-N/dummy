package au.com.westpac.ulo.db.vo;

public class DomainCustomer {

	private double customerId;
	private String customerNum;
	private String Domain;
	private String cisKey;
	private Customer customer;
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public double getCustomerId() {
		return customerId;
	}
	public void setCustomerId(double customerId) {
		this.customerId = customerId;
	}
	public String getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	public String getCisKey() {
		return cisKey;
	}
	public void setCisKey(String cisKey) {
		this.cisKey = cisKey;
	}
	
}
