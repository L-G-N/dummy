package au.com.westpac.ulo.db.vo;

import java.sql.Timestamp;

public class SmsDetails {
	private String smsId;
	private String mobileNumber;
	private String activationCode;
	private Timestamp createDdt;
	private Timestamp updateDt;
	public String getSmsId() {
		return smsId;
	}
	public void setSmsId(String smsId) {
		this.smsId = smsId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getActivationCode() {
		return activationCode;
	}
	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}
	public Timestamp getCreateDdt() {
		return createDdt;
	}
	public void setCreateDdt(Timestamp createDdt) {
		this.createDdt = createDdt;
	}
	public Timestamp getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	
	
}
