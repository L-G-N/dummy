package au.com.westpac.ulo.db.vo;

import java.sql.Timestamp;

public class CustMobile {

	private double custMobileId;
	private double customerId;
	private String cplc;
	private String mobileName;
	private char status;
	private Timestamp creationDt;
	private Timestamp updationDt;
	private Timestamp lastCardRmvDt;
	private String memoText;
	private char fctResetRsn;
	private Timestamp frCaseOpenDt;
	private MobileCard mobileCard;

	public MobileCard getMobileCard() {
		return mobileCard;
	}

	public void setMobileCard(MobileCard mobileCard) {
		this.mobileCard = mobileCard;
	}

	public double getCustMobileId() {
		return custMobileId;
	}

	public void setCustMobileId(double custMobileId) {
		this.custMobileId = custMobileId;
	}

	public double getCustomerId() {
		return customerId;
	}

	public void setCustomerId(double customerId) {
		this.customerId = customerId;
	}

	public String getCplc() {
		return cplc;
	}

	public void setCplc(String cplc) {
		this.cplc = cplc;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public Timestamp getUpdationDt() {
		return updationDt;
	}

	public void setUpdationDt(Timestamp updationDt) {
		this.updationDt = updationDt;
	}

	public Timestamp getLastCardRmvDt() {
		return lastCardRmvDt;
	}

	public void setLastCardRmvDt(Timestamp lastCardRmvDt) {
		this.lastCardRmvDt = lastCardRmvDt;
	}

	public String getMemoText() {
		return memoText;
	}

	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}

	public char getFctResetRsn() {
		return fctResetRsn;
	}

	public void setFctResetRsn(char fctResetRsn) {
		this.fctResetRsn = fctResetRsn;
	}

	public Timestamp getFrCaseOpenDt() {
		return frCaseOpenDt;
	}

	public void setFrCaseOpenDt(Timestamp frCaseOpenDt) {
		this.frCaseOpenDt = frCaseOpenDt;
	}

	public Timestamp getFrCaseCloseDt() {
		return frCaseCloseDt;
	}

	public void setFrCaseCloseDt(Timestamp frCaseCloseDt) {
		this.frCaseCloseDt = frCaseCloseDt;
	}

	public String getAppBand() {
		return appBand;
	}

	public void setAppBand(String appBand) {
		this.appBand = appBand;
	}

	private Timestamp frCaseCloseDt;
	private String appBand;

}
