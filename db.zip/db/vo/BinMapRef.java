package au.com.westpac.ulo.db.vo;

public class BinMapRef {

	private double binNumber;
	private String schema;
	private String Bank;
	private String cardType;
	public double getBinNumber() {
		return binNumber;
	}
	public void setBinNumber(double binNumber) {
		this.binNumber = binNumber;
	}
	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getBank() {
		return Bank;
	}
	public void setBank(String bank) {
		Bank = bank;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	
	
}
