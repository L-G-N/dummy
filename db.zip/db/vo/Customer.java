package au.com.westpac.ulo.db.vo;
import java.sql.Timestamp;

public class Customer {

	private double customerId;
	private String firstNm;
	private String middleNm;
	private String lastNm;
	private DomainCustomer domainCustomer;
	public DomainCustomer getDomainCustomer() {
		return domainCustomer;
	}
	public void setDomainCustomer(DomainCustomer domainCustomer) {
		this.domainCustomer = domainCustomer;
	}
	public double getCustomerId() {
		return customerId;
	}
	public void setCustomerId(double customerId) {
		this.customerId = customerId;
	}
	public String getFirstNm() {
		return firstNm;
	}
	public void setFirstNm(String firstNm) {
		this.firstNm = firstNm;
	}
	public String getMiddleNm() {
		return middleNm;
	}
	public void setMiddleNm(String middleNm) {
		this.middleNm = middleNm;
	}
	public String getLastNm() {
		return lastNm;
	}
	public void setLastNm(String lastNm) {
		this.lastNm = lastNm;
	}
	public Timestamp getBirthDt() {
		return birthDt;
	}
	public void setBirthDt(Timestamp birthDt) {
		this.birthDt = birthDt;
	}
	private Timestamp birthDt;
	
}
