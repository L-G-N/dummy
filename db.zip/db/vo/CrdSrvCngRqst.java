package au.com.westpac.ulo.db.vo;

import java.sql.Timestamp;

public class CrdSrvCngRqst {

private String serviceType;
private Timestamp creationDt;
private String cardNumber;
public String getServiceType() {
	return serviceType;
}
public void setServiceType(String serviceType) {
	this.serviceType = serviceType;
}
public Timestamp getCreationDt() {
	return creationDt;
}
public void setCreationDt(Timestamp creationDt) {
	this.creationDt = creationDt;
}
public String getCardNumber() {
	return cardNumber;
}
public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}
public String getSourceChannel() {
	return sourceChannel;
}
public void setSourceChannel(String sourceChannel) {
	this.sourceChannel = sourceChannel;
}
public String getCardSuffix() {
	return CardSuffix;
}
public void setCardSuffix(String cardSuffix) {
	CardSuffix = cardSuffix;
}
public String getCardExpiryDt() {
	return cardExpiryDt;
}
public void setCardExpiryDt(String cardExpiryDt) {
	this.cardExpiryDt = cardExpiryDt;
}
public String getCompanionBaseCard() {
	return companionBaseCard;
}
public void setCompanionBaseCard(String companionBaseCard) {
	this.companionBaseCard = companionBaseCard;
}
public String getCisKey() {
	return cisKey;
}
public void setCisKey(String cisKey) {
	this.cisKey = cisKey;
}
public String getCustomerNbr() {
	return customerNbr;
}
public void setCustomerNbr(String customerNbr) {
	this.customerNbr = customerNbr;
}
public String getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getSrhSource() {
	return srhSource;
}
public void setSrhSource(String srhSource) {
	this.srhSource = srhSource;
}
public String getSrhOriGbsb() {
	return srhOriGbsb;
}
public void setSrhOriGbsb(String srhOriGbsb) {
	this.srhOriGbsb = srhOriGbsb;
}
public String getSrhOrigSystem() {
	return srhOrigSystem;
}
public void setSrhOrigSystem(String srhOrigSystem) {
	this.srhOrigSystem = srhOrigSystem;
}
public String getSrhUserContext() {
	return srhUserContext;
}
public void setSrhUserContext(String srhUserContext) {
	this.srhUserContext = srhUserContext;
}
public String getSrhFunctional() {
	return srhFunctional;
}
public void setSrhFunctional(String srhFunctional) {
	this.srhFunctional = srhFunctional;
}
public String getSrhCorrelationId() {
	return srhCorrelationId;
}
public void setSrhCorrelationId(String srhCorrelationId) {
	this.srhCorrelationId = srhCorrelationId;
}
public String getRequestCompleted() {
	return requestCompleted;
}
public void setRequestCompleted(String requestCompleted) {
	this.requestCompleted = requestCompleted;
}
public String getProcessErrorCode() {
	return processErrorCode;
}
public void setProcessErrorCode(String processErrorCode) {
	this.processErrorCode = processErrorCode;
}
public String getProcessErrorDesc() {
	return processErrorDesc;
}
public void setProcessErrorDesc(String processErrorDesc) {
	this.processErrorDesc = processErrorDesc;
}
public String getStaffChannel() {
	return staffChannel;
}
public void setStaffChannel(String staffChannel) {
	this.staffChannel = staffChannel;
}
public String getIpAddress() {
	return ipAddress;
}
public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
}
public String getCookieId() {
	return cookieId;
}
public void setCookieId(String cookieId) {
	this.cookieId = cookieId;
}
public String getStaffSalaryId() {
	return staffSalaryId;
}
public void setStaffSalaryId(String staffSalaryId) {
	this.staffSalaryId = staffSalaryId;
}
public String getCallerId() {
	return callerId;
}
public void setCallerId(String callerId) {
	this.callerId = callerId;
}
public String getIsDeleted() {
	return isDeleted;
}
public void setIsDeleted(String isDeleted) {
	this.isDeleted = isDeleted;
}
public String getORIGBRANCHBSB() {
	return ORIGBRANCHBSB;
}
public void setORIGBRANCHBSB(String oRIGBRANCHBSB) {
	ORIGBRANCHBSB = oRIGBRANCHBSB;
}
public String getFirstIssueCard() {
	return firstIssueCard;
}
public void setFirstIssueCard(String firstIssueCard) {
	this.firstIssueCard = firstIssueCard;
}
public String getOrg() {
	return org;
}
public void setOrg(String org) {
	this.org = org;
}
public String getLogo() {
	return logo;
}
public void setLogo(String logo) {
	this.logo = logo;
}
public String getMemoText() {
	return memoText;
}
public void setMemoText(String memoText) {
	this.memoText = memoText;
}
public String getActionCode() {
	return actionCode;
}
public void setActionCode(String actionCode) {
	this.actionCode = actionCode;
}
public String getIsChipBasedCard() {
	return isChipBasedCard;
}
public void setIsChipBasedCard(String isChipBasedCard) {
	this.isChipBasedCard = isChipBasedCard;
}
public String getOldEmbosserName() {
	return oldEmbosserName;
}
public void setOldEmbosserName(String oldEmbosserName) {
	this.oldEmbosserName = oldEmbosserName;
}
public String getOldExpiryDt() {
	return oldExpiryDt;
}
public void setOldExpiryDt(String oldExpiryDt) {
	this.oldExpiryDt = oldExpiryDt;
}
public String getReIssuerSn() {
	return reIssuerSn;
}
public void setReIssuerSn(String reIssuerSn) {
	this.reIssuerSn = reIssuerSn;
}
public String getBlckCdeActn() {
	return blckCdeActn;
}
public void setBlckCdeActn(String blckCdeActn) {
	this.blckCdeActn = blckCdeActn;
}
public String getNewBlckCde() {
	return newBlckCde;
}
public void setNewBlckCde(String newBlckCde) {
	this.newBlckCde = newBlckCde;
}
public String getLmtUpdtLttr() {
	return lmtUpdtLttr;
}
public void setLmtUpdtLttr(String lmtUpdtLttr) {
	this.lmtUpdtLttr = lmtUpdtLttr;
}
public String getCrrntLmt() {
	return crrntLmt;
}
public void setCrrntLmt(String crrntLmt) {
	this.crrntLmt = crrntLmt;
}
public String getNewCrdtLmt() {
	return newCrdtLmt;
}
public void setNewCrdtLmt(String newCrdtLmt) {
	this.newCrdtLmt = newCrdtLmt;
}
public String getPrdctMaxLmt() {
	return prdctMaxLmt;
}
public void setPrdctMaxLmt(String prdctMaxLmt) {
	this.prdctMaxLmt = prdctMaxLmt;
}
public String getPrdctMinLmt() {
	return prdctMinLmt;
}
public void setPrdctMinLmt(String prdctMinLmt) {
	this.prdctMinLmt = prdctMinLmt;
}
public String getCafNoteCtgry() {
	return cafNoteCtgry;
}
public void setCafNoteCtgry(String cafNoteCtgry) {
	this.cafNoteCtgry = cafNoteCtgry;
}
public String getCafNotes() {
	return cafNotes;
}
public void setCafNotes(String cafNotes) {
	this.cafNotes = cafNotes;
}
public String getStffmmbrassstd() {
	return stffmmbrassstd;
}
public void setStffmmbrassstd(String stffmmbrassstd) {
	this.stffmmbrassstd = stffmmbrassstd;
}
public String getHwwsCrdLststln() {
	return HwwsCrdLststln;
}
public void setHwwsCrdLststln(String hwwsCrdLststln) {
	HwwsCrdLststln = hwwsCrdLststln;
}
public String getWhnwsCrdLststln() {
	return whnwsCrdLststln;
}
public void setWhnwsCrdLststln(String whnwsCrdLststln) {
	this.whnwsCrdLststln = whnwsCrdLststln;
}
public String getWsPinRcrddwthCrd() {
	return wsPinRcrddwthCrd;
}
public void setWsPinRcrddwthCrd(String wsPinRcrddwthCrd) {
	this.wsPinRcrddwthCrd = wsPinRcrddwthCrd;
}
public String getIsRplcmntCrdRqstd() {
	return isRplcmntCrdRqstd;
}
public void setIsRplcmntCrdRqstd(String isRplcmntCrdRqstd) {
	this.isRplcmntCrdRqstd = isRplcmntCrdRqstd;
}
public String getLastStepNm() {
	return lastStepNm;
}
public void setLastStepNm(String lastStepNm) {
	this.lastStepNm = lastStepNm;
}
public String getMarkedForRetry() {
	return markedForRetry;
}
public void setMarkedForRetry(String markedForRetry) {
	this.markedForRetry = markedForRetry;
}
public String getMarkedForSupport() {
	return markedForSupport;
}
public void setMarkedForSupport(String markedForSupport) {
	this.markedForSupport = markedForSupport;
}
public String getProducttype() {
	return Producttype;
}
public void setProducttype(String producttype) {
	Producttype = producttype;
}
public String getCardBusType() {
	return cardBusType;
}
public void setCardBusType(String cardBusType) {
	this.cardBusType = cardBusType;
}
public String getNbrOfCardHolders() {
	return nbrOfCardHolders;
}
public void setNbrOfCardHolders(String nbrOfCardHolders) {
	this.nbrOfCardHolders = nbrOfCardHolders;
}
public String getReIssueBaseAmex() {
	return reIssueBaseAmex;
}
public void setReIssueBaseAmex(String reIssueBaseAmex) {
	this.reIssueBaseAmex = reIssueBaseAmex;
}
public String getNewCardNumber() {
	return newCardNumber;
}
public void setNewCardNumber(String newCardNumber) {
	this.newCardNumber = newCardNumber;
}
public String getNewExpiryDate() {
	return newExpiryDate;
}
public void setNewExpiryDate(String newExpiryDate) {
	this.newExpiryDate = newExpiryDate;
}
public String getExtendExpiry() {
	return extendExpiry;
}
public void setExtendExpiry(String extendExpiry) {
	this.extendExpiry = extendExpiry;
}
public String getNewEmbssrnm() {
	return newEmbssrnm;
}
public void setNewEmbssrnm(String newEmbssrnm) {
	this.newEmbssrnm = newEmbssrnm;
}
public String getIsWriteBackDone() {
	return isWriteBackDone;
}
public void setIsWriteBackDone(String isWriteBackDone) {
	this.isWriteBackDone = isWriteBackDone;
}
public Timestamp getUpdationDt() {
	return updationDt;
}
public void setUpdationDt(Timestamp updationDt) {
	this.updationDt = updationDt;
}
public char getRegFrTeleBnkng() {
	return regFrTeleBnkng;
}
public void setRegFrTeleBnkng(char regFrTeleBnkng) {
	this.regFrTeleBnkng = regFrTeleBnkng;
}
public char getCliCnsntVal() {
	return cliCnsntVal;
}
public void setCliCnsntVal(char cliCnsntVal) {
	this.cliCnsntVal = cliCnsntVal;
}
public char getCliCnsntLvl() {
	return cliCnsntLvl;
}
public void setCliCnsntLvl(char cliCnsntLvl) {
	this.cliCnsntLvl = cliCnsntLvl;
}
public Timestamp getCliCnsntDt() {
	return cliCnsntDt;
}
public void setCliCnsntDt(Timestamp cliCnsntDt) {
	this.cliCnsntDt = cliCnsntDt;
}
private String sourceChannel;
private String CardSuffix;
private String cardExpiryDt;
private String companionBaseCard;
private String cisKey;
private String customerNbr;
private String dateOfBirth;
private String srhSource;
private String srhOriGbsb;
private String srhOrigSystem;
private String srhUserContext;
private String srhFunctional;
private String srhCorrelationId;
private String requestCompleted;
private String processErrorCode;
private String processErrorDesc;
private String staffChannel;
private String ipAddress;
private String cookieId;
private String staffSalaryId;
private String callerId;
private String isDeleted;
private String ORIGBRANCHBSB;
private String firstIssueCard;
private String org;
private String logo;
private String memoText;
private String actionCode;
private String isChipBasedCard;
private String oldEmbosserName;
private String oldExpiryDt;
private String reIssuerSn;
private String blckCdeActn;
private String newBlckCde;
private String lmtUpdtLttr;
private String crrntLmt;
private String newCrdtLmt;
private String prdctMaxLmt;
private String prdctMinLmt;
private String cafNoteCtgry;
private String cafNotes;
private String stffmmbrassstd;
private String HwwsCrdLststln;
private String whnwsCrdLststln;
private String wsPinRcrddwthCrd;
private String isRplcmntCrdRqstd;
private String lastStepNm;
private String markedForRetry;
private String markedForSupport;
private String Producttype;
private String cardBusType;
private String nbrOfCardHolders;
private String reIssueBaseAmex;
private String newCardNumber;
private String newExpiryDate;
private String extendExpiry;
private String newEmbssrnm;
private String isWriteBackDone;
private Timestamp updationDt;
private char regFrTeleBnkng;
private char cliCnsntVal;
private char cliCnsntLvl;
private Timestamp cliCnsntDt;
}
