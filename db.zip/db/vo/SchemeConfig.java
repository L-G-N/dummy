package au.com.westpac.ulo.db.vo;

public class SchemeConfig {
	
	private String ConfigParam;
	private String ConfigValue;
	public String getConfigParam() {
		return ConfigParam;
	}
	public void setConfigParam(String configParam) {
		ConfigParam = configParam;
	}
	public String getConfigValue() {
		return ConfigValue;
	}
	public void setConfigValue(String configValue) {
		ConfigValue = configValue;
	}

}
