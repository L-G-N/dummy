package au.com.westpac.ulo.db.vo;

public class ActivationMethodRef {

	private String activationMethodId;
	private String Description;
	private String activationValue;
	private String activationType;
	public String getActivationMethodId() {
		return activationMethodId;
	}
	public void setActivationMethodId(String activationMethodId) {
		this.activationMethodId = activationMethodId;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getActivationValue() {
		return activationValue;
	}
	public void setActivationValue(String activationValue) {
		this.activationValue = activationValue;
	}
	
	public String getActivationType() {
		return activationType;
	}
	public void setActivationType(String activationType) {
		this.activationType = activationType;
	}
}
