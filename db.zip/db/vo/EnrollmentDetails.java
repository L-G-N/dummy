package au.com.westpac.ulo.db.vo;

import java.sql.Timestamp;

public class EnrollmentDetails {

	
		private String correlationId;
		private String walletId;
		private String embossingName;
		private String deviceId;
		private double fpan;
		private double dpan;
		private String reasonCode;
		private String status;
		private String customer1;
		private String customer2;
		private String lock;
		private String serviceType;
		private Timestamp createDate;
		private Timestamp updateDate;
		public String getServiceType() {
			return serviceType;
		}
		public void setServiceType(String serviceType) {
			this.serviceType = serviceType;
		}
		
		public String getCorrelationId() {
			return correlationId;
		}
		public void setCorrelationId(String correlationId) {
			this.correlationId = correlationId;
		}
		public String getWalletId() {
			return walletId;
		}
		public void setWalletId(String walletId) {
			this.walletId = walletId;
		}
		public String getEmbossingName() {
			return embossingName;
		}
		public void setEmbossingName(String embossingName) {
			this.embossingName = embossingName;
		}
		public String getDeviceId() {
			return deviceId;
		}
		public void setDeviceId(String deviceId) {
			this.deviceId = deviceId;
		}
		public double getFpan() {
			return fpan;
		}
		public void setFpan(double fpan) {
			this.fpan = fpan;
		}
		public double getDpan() {
			return dpan;
		}
		public void setDpan(double dpan) {
			this.dpan = dpan;
		}
		public String getReasonCode() {
			return reasonCode;
		}
		public void setReasonCode(String reasonCode) {
			this.reasonCode = reasonCode;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getCustomer1() {
			return customer1;
		}
		public void setCustomer1(String customer1) {
			this.customer1 = customer1;
		}
		public String getCustomer2() {
			return customer2;
		}
		public void setCustomer2(String customer2) {
			this.customer2 = customer2;
		}
		
		public String getLock() {
			return lock;
		}
		public void setLock(String lock) {
			this.lock = lock;
		}
		public Timestamp getCreateDate() {
			return createDate;
		}
		public void setCreateDate(Timestamp createDate) {
			this.createDate = createDate;
		}
		public Timestamp getUpdateDate() {
			return updateDate;
		}
		public void setUpdateDate(Timestamp updateDate) {
			this.updateDate = updateDate;
		}
	
		}


