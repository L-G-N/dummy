package au.com.westpac.ulo.db.vo;

public class ApproductsRef {

	private double productId;
	private String carDart;
	private String description;
	private String contract;
	public double getProductId() {
		return productId;
	}
	public void setProductId(double productId) {
		this.productId = productId;
	}
	public String getCarDart() {
		return carDart;
	}
	public void setCarDart(String carDart) {
		this.carDart = carDart;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContract() {
		return contract;
	}
	public void setContract(String contract) {
		this.contract = contract;
	}
	
}
