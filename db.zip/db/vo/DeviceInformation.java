package au.com.westpac.ulo.db.vo;

public class DeviceInformation {
	private String deviceName;
	private String deviceId;
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getIsoDeviceType() {
		return isoDeviceType;
	}
	public void setIsoDeviceType(String isoDeviceType) {
		this.isoDeviceType = isoDeviceType;
	}
	public String getWalletId() {
		return WalletId;
	}
	public void setWalletId(String walletId) {
		WalletId = walletId;
	}
	private String isoDeviceType;
	private String WalletId;
	

}
