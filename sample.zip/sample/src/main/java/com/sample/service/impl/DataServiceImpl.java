/**
 * 
 */
package com.sample.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.dao.CityDAO;
import com.sample.service.DataService;

/**
 * @author LGN
 *
 */
@Service("dataserviceimpl")
@Transactional
public class DataServiceImpl implements DataService {

	@Autowired
	private CityDAO citydao;
	
	public List<CityDetails> getCities() {
		return citydao.getCities();
	}

	public Boolean createCity(CityDetails citiesDetails) {
		return citydao.createCity(citiesDetails);
	}

	public Boolean updateCity(CityDetails citiesDetails) {
		return citydao.updateCity(citiesDetails);
	}

	public Boolean blockCity(String cityid) {
		return citydao.blockCity(cityid);
	}

}
