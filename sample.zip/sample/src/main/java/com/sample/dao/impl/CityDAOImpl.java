/**
 * 
 */
package com.sample.dao.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sample.dao.AbstractDao;
import com.sample.dao.CityDAO;
import com.sample.model.CityDetails;
import com.sample.util.Constants;
import com.sample.util.sampleUtil;
import com.sample.util.QueryConstants;

/**
 * @author LGN
 *
 */
@Repository("CityDAO")
@Transactional
public class CityDAOImpl extends AbstractDao<Integer, CityDetails> implements CityDAO {

	@SuppressWarnings("unchecked")
	public List<CityDetails> getCities() {
		return (List<CityDetails>) createEntityCriteria().list();
	}

	public Boolean createCity(CityDetails citiesDetails) {
		boolean result = false;
		try {
			citiesDetails.setCityId(sampleUtil.getPrimaryId(
					(String) createEntityCriteria().setProjection(Projections.max(Constants.CITYID)).uniqueResult()));
			persist(citiesDetails);
			result = true;
		} catch (HibernateException he) {
			System.out.println("HibernateException ::" + he);
		}
		return result;
	}

	public Boolean updateCity(CityDetails citiesDetails) {
		boolean result = false;
		try {
			getSession().saveOrUpdate(citiesDetails);
			result = true;
		} catch (HibernateException he) {
			System.out.println("HibernateException ::" + he);
		}
		return result;
	}

	public Boolean blockCity(String cityId) {
		boolean result = false;
		try {
			System.out.println("cityId ::::::::"+cityId);
			getSession().createQuery(QueryConstants.DELET_CITY).setString(Constants.CITYID, cityId).executeUpdate();
			result = true;
		} catch (HibernateException he) {
			System.out.println("HibernateException ::" + he);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> getCity() {
		Query query = getSession().createSQLQuery(QueryConstants.CITY_DETAIL);
		return query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();
	}

}
