/**
 * 
 */
package com.sample.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sample.model.CityDetails;

/**
 * @author LGN
 *
 */
@Repository("CityDAO")
@Transactional
public interface CityDAO {

	/**
	 * Get the cities details
	 * @return
	 */
	List<CityDetails> getCities();

	/**
	 * @author LGN
	 * Add the given object details into DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean createCity(CityDetails citiesDetails);

	/**
	 * @author LGN
	 * Update the given object details into DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean updateCity(CityDetails citiesDetails);

	/**
	 * @author LGN
	 * Block the given city id details in DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean blockCity(String cityid);

	/**
	 * get a city details with count of area
	 * @return
	 */
	List<Map<String,Object>> getCity();

}
