/**
 * 
 */
package com.sample.util;

/**
 * @author LGN
 *
 */
public class Constants {

	public static final String REGEX = "^[^\\d]*";
	public static final String EMPTY_STRING = "";
	public static final String PADDING_LETTER = "0";
	
	//primary key column names for Data base tables
	public static final String CITYID ="cityId";
	public static final String AREAID = "areaId";
	
	
	public static final String CITYDEATILS_CITYID = "cityDetails.cityId";
	
	
}
