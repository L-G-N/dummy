/**
 * 
 */
package com.sample.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sample.model.Cardstatus;
import com.sample.service.DataService;

/**
 * @author LGN
 *
 */
@RestController
@RequestMapping("/cardstatus")
public class CardstatusController {

	@Autowired
	private DataService dataservice;

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public ResponseEntity<List<Cardstatus>> getCardstatus() {
		List<Cardstatus> list = dataservice.getCardStatus();
		if(list.isEmpty()){
			return new ResponseEntity<List<Cardstatus>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Cardstatus>>(list,HttpStatus.OK);
	}

	/*@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<Boolean> createCity(@RequestBody Cardstatus citiesDetails) {
		Boolean flag = dataservice.createCity(citiesDetails);
		if(!flag)
			return new ResponseEntity<Boolean>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<Boolean>(flag, HttpStatus.OK);
	}

	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public ResponseEntity<Boolean> updateCity(@RequestBody Cardstatus citiesDetails) {
		Boolean flag = dataservice.updateCity(citiesDetails);
		if(!flag)
			return new ResponseEntity<Boolean>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<Boolean>(flag, HttpStatus.OK);
	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public ResponseEntity<Boolean> getLabsSrv2(@RequestBody String cityid) {
		if(cityid == null)
			return new ResponseEntity<Boolean>(HttpStatus.NO_CONTENT);
		Boolean flag = dataservice.blockCity(cityid);
		if(!flag)
			return new ResponseEntity<Boolean>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<Boolean>(flag, HttpStatus.OK);
	}
*/
}
