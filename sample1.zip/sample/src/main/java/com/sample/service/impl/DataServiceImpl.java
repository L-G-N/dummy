/**
 * 
 */
package com.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.dao.CardStatusDAO;
import com.sample.model.Cardstatus;
import com.sample.service.DataService;

/**
 * @author LGN
 *
 */
@Service("dataserviceimpl")
@Transactional
public class DataServiceImpl implements DataService {

	@Autowired
	private CardStatusDAO citydao;
	
	public List<Cardstatus> getCardStatus() {
		return citydao.getCardStatus();
	}

	public Boolean createCity(Cardstatus citiesDetails) {
		return citydao.createCity(citiesDetails);
	}

	public Boolean updateCity(Cardstatus citiesDetails) {
		return citydao.updateCity(citiesDetails);
	}

	public Boolean blockCity(String cityid) {
		return citydao.blockCity(cityid);
	}

}
