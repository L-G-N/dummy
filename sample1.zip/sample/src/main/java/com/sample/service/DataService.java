/**
 * 
 */
package com.sample.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sample.model.Cardstatus;

/**
 * @author LGN
 *
 */
@Service("dataservice")
public interface DataService {

	/**
	 * @author LGN get City details
	 * @return
	 */
	List<Cardstatus> getCardStatus();

	/**
	 * @author LGN Add the given object details into DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean createCity(Cardstatus citiesDetails);

	/**
	 * @author LGN Update the given object details into DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean updateCity(Cardstatus citiesDetails);

	/**
	 * @author LGN Block the given city id details in DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean blockCity(String cityid);


	
}
