/**
 * 
 */
package com.sample.util;

/**
 * @author LGN
 *
 */
public class QueryConstants {

	public static final String DELET_CITY = "delete from Cardstatus where cityId= :cityId";
	
}
