/**
 * 
 */
package com.sample.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sample.model.Cardstatus;

/**
 * @author LGN
 *
 */
@Repository("CardStatusDAO")
@Transactional
public interface CardStatusDAO {

	/**
	 * Get the cities details
	 * @return
	 */
	List<Cardstatus> getCardStatus();

	/**
	 * @author LGN
	 * Add the given object details into DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean createCity(Cardstatus citiesDetails);

	/**
	 * @author LGN
	 * Update the given object details into DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean updateCity(Cardstatus citiesDetails);

	/**
	 * @author LGN
	 * Block the given city id details in DB
	 * @param citiesDetails
	 * @return
	 */
	Boolean blockCity(String cityid);

}
