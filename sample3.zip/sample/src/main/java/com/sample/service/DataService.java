/**
 * 
 */
package com.sample.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sample.model.Enrollmentdetails;

/**
 * @author LGN
 *
 */
@Service("dataservice")
public interface DataService {

	/**
	 * @author LGN get City details
	 * @return
	 */
	List<Enrollmentdetails> get();



	
}
