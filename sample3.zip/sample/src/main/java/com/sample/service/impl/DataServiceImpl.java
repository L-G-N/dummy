/**
 * 
 */
package com.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sample.dao.EnrollmentdetailsDAO;
import com.sample.model.Enrollmentdetails;
import com.sample.service.DataService;

/**
 * @author LGN
 *
 */
@Service("dataserviceimpl")
@Transactional
public class DataServiceImpl implements DataService {

	@Autowired
	private EnrollmentdetailsDAO enrollmentdetailsDAO;

	@Override
	public List<Enrollmentdetails> get() {
		return enrollmentdetailsDAO.get();
	}
	
	

}
