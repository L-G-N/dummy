/**
 * 
 */
package com.sample.util;

/**
 * @author LGN
 *
 */
public class sampleUtil {

	public static String getPrimaryId(String existingId) {
		String generatedID = null;
		int length = existingId.length();
		
		int positionOfPrefix = existingId.length() - existingId.replaceAll(Constants.REGEX, Constants.EMPTY_STRING).length() + 1;
		String prefix = existingId.substring(0, positionOfPrefix-1);
		int id = Integer.parseInt(existingId.substring(positionOfPrefix-1, length));
		generatedID = prefix
				+ org.apache.commons.lang3.StringUtils.leftPad(Constants.EMPTY_STRING + (id + 1), length - prefix.length(), Constants.PADDING_LETTER);
		System.out.println("generatedID  ::::::"+generatedID);
		return generatedID;
	}

}
