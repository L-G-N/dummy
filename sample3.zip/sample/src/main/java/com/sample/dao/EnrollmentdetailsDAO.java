/**
 * 
 */
package com.sample.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sample.model.Cardstatus;
import com.sample.model.Enrollmentdetails;

/**
 * @author LGN
 *
 */
@Repository("EnrollmentdetailsDAO")
@Transactional
public interface EnrollmentdetailsDAO {

	/**
	 * get the enrollment details 
	 * @return
	 */
	List<Enrollmentdetails> get();
	
}
