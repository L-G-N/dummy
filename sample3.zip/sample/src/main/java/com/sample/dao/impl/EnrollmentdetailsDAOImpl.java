/**
 * 
 */
package com.sample.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sample.dao.AbstractDao;
import com.sample.dao.EnrollmentdetailsDAO;
import com.sample.model.Enrollmentdetails;

/**
 * @author LGN
 *
 */
@Repository("EnrollmentdetailsDAO")
@Transactional
public class EnrollmentdetailsDAOImpl extends AbstractDao<Integer, Enrollmentdetails> implements EnrollmentdetailsDAO {

	@SuppressWarnings("unchecked")
	@Override
	public List<Enrollmentdetails> get() {
		System.out.println("DAO start");
		List<Enrollmentdetails> list = createEntityCriteria().list();
		System.out.println(list.isEmpty());
		System.out.println("DAO end");
		return list;
	}

}
